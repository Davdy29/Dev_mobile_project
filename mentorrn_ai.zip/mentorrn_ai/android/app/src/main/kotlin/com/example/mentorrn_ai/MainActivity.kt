package com.example.mentorrn_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
