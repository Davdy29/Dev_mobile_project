import 'package:flutter/material.dart';
import '../services/mistral_service.dart';
import '../services/speech_service.dart';

class ChatScreen extends StatefulWidget {
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  List<Map<String, String>> messages = [];

  void sendMessage() async {
    String userMessage = _controller.text;
    setState(() {
      messages.add({"role": "user", "text": userMessage});
    });
    _controller.clear();

    String botResponse = await MistralService.getResponse(userMessage);
    setState(() {
      messages.add({"role": "bot", "text": botResponse});
    });
  }

  void recordAndSendMessage() async {
    String spokenText = await SpeechService.recognizeSpeech();
    setState(() {
      messages.add({"role": "user", "text": spokenText});
    });

    String botResponse = await MistralService.getResponse(spokenText);
    setState(() {
      messages.add({"role": "bot", "text": botResponse});
    });
  }

  void speakLastBotResponse() {
    if (messages.isNotEmpty) {
      String lastBotMessage = messages.lastWhere(
              (msg) => msg["role"] == "bot",
          orElse: () => {"text": ""}
      )["text"]!;
      SpeechService.speak(lastBotMessage);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Discuter avec MentorAI")),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: messages.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(messages[index]["text"]!),
                  tileColor: messages[index]["role"] == "user" ? Colors.blue[100] : Colors.grey[200],
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(hintText: "Écrivez un message..."),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.mic), // 🎤 Bouton micro
                  onPressed: recordAndSendMessage,
                ),
                IconButton(
                  icon: Icon(Icons.send), // 📩 Bouton envoyer
                  onPressed: sendMessage,
                ),
                IconButton(
                  icon: Icon(Icons.volume_up), // 🔊 Bouton écouter
                  onPressed: speakLastBotResponse, // ✅ Lire la dernière réponse du bot
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

