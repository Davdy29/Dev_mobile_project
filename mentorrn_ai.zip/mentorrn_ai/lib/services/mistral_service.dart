import 'dart:convert';
import 'package:http/http.dart' as http;

class MistralService {
  static const String apiKey = "VOTRE_CLE_MISTRAL"; // 🔥 Remplace par ta clé API
  static const String endpoint = "https://api.mistral.ai/v1/chat";

  static Future<String> getResponse(String message) async {
    final response = await http.post(
      Uri.parse(endpoint),
      headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'message': message,
        'mode': 'language-learning' // Mode spécial pour apprentissage des langues
      }),
    );

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      return data["response"];
    } else {
      return "Je n’ai pas compris, peux-tu reformuler ?";
    }
  }
}

