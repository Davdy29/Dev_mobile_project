import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';

class SpeechService {
  static final FlutterTts _tts = FlutterTts();
  static final stt.SpeechToText _speech = stt.SpeechToText();

  // 🔊 Synthèse vocale (lecture des phrases)
  static Future<void> speak(String text) async {
    await _tts.setLanguage("en-US");
    await _tts.setPitch(1.0);
    await _tts.speak(text);
  }

  // 🎤 Reconnaissance vocale (conversion parole → texte)
  static Future<String> recognizeSpeech() async {
    bool available = await _speech.initialize();
    if (!available) {
      return "La reconnaissance vocale n'est pas disponible.";
    }

    await _speech.listen();
    await Future.delayed(Duration(seconds: 3)); // Attendre la capture de la parole
    _speech.stop();

    return _speech.lastRecognizedWords; // Retourne le texte transcrit
  }
}
